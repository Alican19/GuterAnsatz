const axios = require('axios');

const data = {
    temperature: 22.5,
    humidity: 60
};

axios.post('https://raspi-daten-test-gwdme5hshdf5ddb3.canadacentral-01.azurewebsites.net/data', data)
    .then(response => {
        console.log('Daten erfolgreich gesendet:', response.data);
    })
    .catch(error => {
        console.error('Fehler beim Senden der Daten:', error);
    });
